# ------------------------------------------------------------
# Ten plik jest częścią zestawu z zajęć z optymalizacji.
# Wersja Python została przygotowana tak, by:
# - zachować możliwie podobne nazwy zmiennych jak w wersji Java,
# - pozostać czytelna (dużo komentarzy krok-po-kroku),
# - dawać się łatwo rozbudować (modułowa struktura: main + genotype + globals/odleglosci).
# ------------------------------------------------------------

# Plik: Komiwojazer_wspinaczkowy.py
# Odpowiednik Java: Komiwojazer_wspinaczkowy.java (projekt komiwojazer_wspinaczkowy_23)


import os
import sys
import math
import random

# Pozwala uruchamiac plik z dowolnego katalogu: python sciezka/do/Komiwojazer_wspinaczkowy.py
sys.path.append(os.path.dirname(__file__))

from genotype import genotype
from odleglosci import odleglosci

# numer biezacego pokolenia
generation = 0

# tablica odleglosci miedzy miastami
tsp = odleglosci()

osobnik = genotype()
nowy = genotype()


def # Inicjalizacja: tworzymy osobnika startowego albo populację startową.
initialize():
    # inicjalizacja losowa genow i kosza, potem wyznaczenie trasy
    global osobnik
    # Główna pętla iteracyjna algorytmu.
# W każdej iteracji generujemy kandydata i decydujemy czy go przyjąć.
for i in range(15, -1, -1):
        osobnik.gene[15 - i] = int(random.random() * 1000) % (i + 1)
        osobnik.kosz[15 - i] = i

    osobnik.ustal_trase()

    print("osobnik")
    for i in range(16):
        print(f"{osobnik.gene[i]}, ", end="")
    print()
    print("trasa")
    for i in range(16):
        print(f"{osobnik.trasa[i]}, ", end="")
    print()


def oblicz_dopasowanie(osob):
    # dla TSP: dopasowanie = dlugosc trasy (minimalizujemy)
    dopasowanie = 0.0

    # domkniecie cyklu: od pierwszego do ostatniego
    dopasowanie = tsp.miasta[osob.trasa[0]][osob.trasa[15]]

    # suma odleglosci kolejnych odcinkow
    for i in range(15):
        dopasowanie += tsp.miasta[osob.trasa[i]][osob.trasa[i + 1]]

    return dopasowanie


def generuj_nowego():
    # modyfikuje losowo wybrany gen, pozostale kopiuje
    global nowy, osobnik

    gen_rand = int(random.random() * 1000) % 16

    # kopiowanie genow
    for i in range(16):
        nowy.gene[i] = osobnik.gene[i]

    # odtworzenie kosza (15..1, a ostatnia wartosc domyslnie zostaje 0)
    for i in range(15, 0, -1):
        nowy.kosz[15 - i] = i

    # modyfikacja jednego genu
    nowy.gene[gen_rand] = int(random.random() * 1000) % (16 - gen_rand)

    # wyznacz trase i policz fitness
    nowy.ustal_trase()
    nowy.# Ocena (fitness): w TSP to zwykle długość trasy (im mniej tym lepiej)
# albo przekształcona wartość (im więcej tym lepiej) przy ruletce.
fitness = oblicz_dopasowanie(nowy)


def # Selekcja / akceptacja: wybieramy czy przejść na nowe rozwiązanie.
select():
    # wybiera lepszego (mniejsza dlugosc trasy)
    global osobnik, nowy
    if nowy.fitness < osobnik.fitness:
        print("zamieniam ")
        for i in range(16):
            osobnik.gene[i] = nowy.gene[i]
        osobnik.fitness = nowy.fitness


def main():
    global generation

    tsp.czytaj_miasta()
    generation = 0
    initialize()

    osobnik.fitness = oblicz_dopasowanie(osobnik)
    print(osobnik.fitness)

    while generation < 10000:
        generuj_nowego()
        # Selekcja / akceptacja: wybieramy czy przejść na nowe rozwiązanie.
select()
        generation += 1
        print(f"generation {generation} fitness {osobnik.fitness}")

    print("The best - geny, trasa")
    for i in range(16):
        print(f"{osobnik.gene[i]}, ", end="")
    print()
    for i in range(16):
        print(f"{osobnik.trasa[i]}, ", end="")
    print()
    print(f"fitness {osobnik.fitness}")

    print("Koniec - Algorytm wspinaczkowy dla optymalizacji komiwojazera")


# Uruchomienie skryptu jako programu.
# W Javie odpowiada to metodzie: public static void main(...)
if __name__ == "__main__":
    main()