# ------------------------------------------------------------
# Ten plik jest częścią zestawu z zajęć z optymalizacji.
# Wersja Python została przygotowana tak, by:
# - zachować możliwie podobne nazwy zmiennych jak w wersji Java,
# - pozostać czytelna (dużo komentarzy krok-po-kroku),
# - dawać się łatwo rozbudować (modułowa struktura: main + genotype + globals/odleglosci).
# ------------------------------------------------------------

# Plik: Globals.py
# Odpowiednik Java: Globals.java (projekt funkcja_ewolucyjny)

# Stałe konfiguracyjne (łatwo je zmienić do eksperymentów)
IL_ZMIENNYCH = 5               # ilosc zmiennych
POPSIZE = 25                   # liczebnosc populacji
MAXGENS = 100                  # maksymalna liczba pokolen (w kodzie wykorzystywany jest warunek na fitness)
PXOVER = 0.8                 # prawdopodobienstwo krzyzowania
PMUTATION = 0.2              # prawdopodobienstwo mutacji